import React, { useState, useEffect, useMemo } from "react";
import { useAuth } from "../../context/AuthContext";
import { apiClient } from "../../api/client";
import {
  Calendar,
  Download,
  Users,
  Clock,
  MapPin,
  CheckCircle,
  ChevronLeft,
  ChevronRight,
  ChevronFirst,
  ChevronLast,
  Loader2,
  Activity,
  Wifi,
  WifiOff,
  Building,
  X,
  Edit,
  Plus,
} from "lucide-react";

interface AttendanceRecord {
  _id: string;
  inspector?: {
    _id: string;
    firstName: string;
    lastName: string;
    username: string;
    email: string;
    role: string;
  };
  userId?: {
    _id: string;
    firstName: string;
    lastName: string;
    username: string;
    email: string;
    role: string;
  };
  tenantId?: {
    _id: string;
    name: string;
    companyName: string;
  };
  loginTime?: string | null;
  logoutTime?: string | null;
  checkInTime?: string | Date | null;
  checkOutTime?: string | Date | null;
  workingHours: number;
  workingMinutes?: number;
  isPresent: boolean;
  presentStatus: string;
  status?: string;
  location?: {
    city?: string;
    country?: string;
    address?: string;
  };
  checkInPlace?: string;
  checkOutPlace?: string;
  shiftName?: string;
  isActive: boolean;
  lastActiveTime: string | null;
  date?: string | Date;
}

interface UserAttendance {
  userId: string;
  firstName: string;
  lastName: string;
  username: string;
  role: string;
  tenantId?: {
    _id: string;
    name: string;
    companyName: string;
  };
  attendance: {
    [date: string]: AttendanceRecord;
  };
}

const formatTime = (dateString: string | null | undefined) => {
  if (!dateString) return "-";
  if (
    typeof dateString === "string" &&
    dateString.match(/^\d{1,2}:\d{2}:\d{2}\s*(am|pm)$/i)
  ) {
    return dateString;
  }
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  return date.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
};

const calculateWorkingHours = (
  loginTime: string | null | undefined,
  logoutTime: string | null | undefined,
  storedHours: number,
) => {
  if (loginTime && !logoutTime) {
    const loginDate = new Date(loginTime);
    const now = new Date();
    return (
      Math.round(
        ((now.getTime() - loginDate.getTime()) / (1000 * 60 * 60)) * 10,
      ) / 10
    );
  }
  return storedHours > 0 ? storedHours : 0;
};

const getMonthDetails = (year: number, month: number) => {
  const firstDay = new Date(year, month - 1, 1);
  const lastDay = new Date(year, month, 0);
  const daysInMonth = lastDay.getDate();
  const startDayOfWeek = firstDay.getDay();
  return {
    year,
    month,
    daysInMonth,
    startDayOfWeek,
    monthName: firstDay.toLocaleString("default", { month: "long" }),
  };
};

const getDatesInMonth = (year: number, month: number) => {
  const dates = [];
  const daysInMonth = new Date(year, month, 0).getDate();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  for (let day = 1; day <= daysInMonth; day++) {
    const dateStr = `${year}-${String(month).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    const date = new Date(year, month - 1, day);
    dates.push({
      date: date,
      dateString: dateStr,
      day: day,
      dayOfWeek: date.toLocaleDateString("en-US", { weekday: "short" }),
      isWeekend: date.getDay() === 0 || date.getDay() === 6,
      isToday: date.toDateString() === today.toDateString(),
      isFuture: date > today,
    });
  }
  return dates;
};

const ITEMS_PER_PAGE = 10;

export default function Attendance() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [userAttendance, setUserAttendance] = useState<UserAttendance[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [hideSuperadmin, setHideSuperadmin] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const [exporting, setExporting] = useState(false);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedUserAttendance, setSelectedUserAttendance] = useState<UserAttendance | null>(null);
  const [showAttendanceModal, setShowAttendanceModal] = useState(false);
  const [editingRecord, setEditingRecord] = useState<AttendanceRecord | null>(null);
  const [editCheckIn, setEditCheckIn] = useState("");
  const [editCheckOut, setEditCheckOut] = useState("");
  const [editStatus, setEditStatus] = useState<"present" | "absent" | "half-day">("present");
  const [editShiftName, setEditShiftName] = useState("");
  const [savingEdit, setSavingEdit] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createAttendanceDate, setCreateAttendanceDate] = useState<string | null>(null);
  const [createAttendanceUserId, setCreateAttendanceUserId] = useState<string | null>(null);
  const [createAttendanceStatus, setCreateAttendanceStatus] = useState<"present" | "absent" | "half-day">("present");
  const [createCheckIn, setCreateCheckIn] = useState("");
  const [createCheckOut, setCreateCheckOut] = useState("");
  const [createShiftName, setCreateShiftName] = useState("");
  const [creatingAttendance, setCreatingAttendance] = useState(false);
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();
  const year = currentYear;
  const month = currentMonth + 1;

  const startDate = useMemo(() => {
    return `${year}-${String(month).padStart(2, '0')}-01`;
  }, [currentMonth, currentYear]);

  const endDate = useMemo(() => {
    const lastDay = new Date(year, month, 0).getDate();
    return `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
  }, [currentMonth, currentYear]);

  // Generate month details for headings and export filename
  const monthDetails = useMemo(() => {
    const firstDay = new Date(year, currentMonth, 1);
    return {
      monthName: firstDay.toLocaleString("default", { month: "long" }),
      year: year,
    };
  }, [currentMonth, year]);

  // Compute dates to display for current month
  const visibleDates = useMemo(() => {
    const dates = [];
    const daysInMonth = new Date(year, month, 0).getDate();
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, currentMonth, d);
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
      dates.push({
        date,
        dateString: dateStr,
        day: d,
        dayOfWeek: date.toLocaleDateString("en-US", { weekday: "short" }),
        isWeekend: date.getDay() === 0 || date.getDay() === 6,
        isToday: date.toDateString() === today.toDateString(),
        isFuture: date > today,
      });
    }
    return dates;
  }, [year, currentMonth, month]);

  // Fetch attendance data using HR report endpoint
  useEffect(() => {
    const fetchAttendance = async () => {
      setLoading(true);
      try {
        console.log(
          "Fetching HR attendance report from",
          startDate,
          "to",
          endDate,
        );
        const response = await apiClient.getHRAttendanceReport({
          startDate,
          endDate,
        });

        console.log("HR Report full response:", response);
        console.log("HR Report keys:", Object.keys(response || {}));

        // API client returns data directly, check various formats
        const logs =
          response?.detailedLogs || response?.data?.detailedLogs || [];
        if (logs && logs.length > 0) {
          console.log("HR Report detailedLogs count:", logs.length);
          console.log("Sample log:", logs[0]);
          processAttendanceData(logs);
        } else {
          console.log(
            "No logs found. Response structure:",
            JSON.stringify(response).substring(0, 500),
          );
          setUserAttendance([]);
        }
      } catch (error: any) {
        console.error("Error fetching attendance:", error?.message || error);
      } finally {
        setLoading(false);
      }
    };

    fetchAttendance();
  }, [startDate, endDate]);

  // Process raw attendance logs into user-based structure (HR Report format)
  const processAttendanceData = (logs: any[]) => {
    const userMap = new Map<string, UserAttendance>();

    logs.forEach((log) => {
      // HR Report format: inspector is a string "FirstName LastName"
      const userName = log.inspector;
      if (!userName) return;

      const nameParts = userName.split(" ");

      if (!userMap.has(userName)) {
        userMap.set(userName, {
          userId: userName,
          firstName: nameParts[0] || "",
          lastName: nameParts.slice(1).join(" ") || "",
          username: "",
          role: "inspector",
          tenantId: log.tenant
            ? { _id: "", name: log.tenant, companyName: log.tenant }
            : undefined,
          attendance: {},
        });
      }

      const user = userMap.get(userName)!;
      const loginDate = log.date; // Already in YYYY-MM-DD format

      if (loginDate) {
        // HR report returns checkIn/checkOut as strings like "5:10:38 pm"
        // We need to store them as strings, not try to parse as Date
        user.attendance[loginDate] = {
          _id: log._id || "",
          userId: {
            _id: "",
            firstName: nameParts[0] || "",
            lastName: nameParts.slice(1).join(" ") || "",
            username: "",
            email: "",
            role: "inspector",
          },
          tenantId: undefined,
          loginTime:
            typeof log.checkIn === "string"
              ? log.checkIn
              : log.checkIn
                ? log.checkIn.toISOString()
                : null,
          logoutTime:
            typeof log.checkOut === "string"
              ? log.checkOut
              : log.checkOut
                ? log.checkOut.toISOString()
                : null,
          workingHours: log.hours || 0,
          isPresent: log.status === "present" || log.status === "late" || (log.hours || 0) > 0 || !!log.checkIn,
          presentStatus: log.status || "present",
          shiftName: log.shift || "No shift",
          checkInTime: typeof log.checkIn === "string" ? log.checkIn : log.checkIn ? log.checkIn.toISOString() : null,
          checkOutTime: typeof log.checkOut === "string" ? log.checkOut : log.checkOut ? log.checkOut.toISOString() : null,
          isActive: false,
          lastActiveTime: null,
          location: log.location ? { address: log.location } : undefined,
          date: loginDate,
        };
      }
    });

    console.log("Processed attendance data:", userMap.size, "users");
    setUserAttendance(Array.from(userMap.values()));
  };

  // Filter users based on search
  const filteredUsers = useMemo(() => {
    let users = userAttendance;

    // Filter by search term
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      users = users.filter(
        (u) =>
          u.firstName.toLowerCase().includes(term) ||
          u.lastName.toLowerCase().includes(term) ||
          u.username.toLowerCase().includes(term),
      );
    }

    // Filter out superadmins if hideSuperadmin is true
    // Superadmins can still see other superadmins if they want
    if (hideSuperadmin && user?.role !== "superadmin") {
      users = users.filter((u) => u.role !== "superadmin");
    }

    return users;
  }, [userAttendance, searchTerm, hideSuperadmin, user?.role]);

  // Paginated users
  const paginatedUsers = useMemo(() => {
    const start = (currentPage - 1) * ITEMS_PER_PAGE;
    return filteredUsers.slice(start, start + ITEMS_PER_PAGE);
  }, [filteredUsers, currentPage]);

  const totalPages = Math.ceil(filteredUsers.length / ITEMS_PER_PAGE);

  // Handle month navigation
  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 2, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month, 1));
  };

  // Generate simple Excel HTML with just P/A/Live
  const generateStyledExcelHTML = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);

    let html = `
            <html>
            <head>
                <meta charset="UTF-8">
                <title>Attendance - ${monthDetails.monthName} ${year}</title>
                <style>
                    body {
                        font-family: 'Segoe UI', Arial, sans-serif;
                        margin: 20px;
                        background: white;
                    }
                    .main-header {
                        background: linear-gradient(135deg, #1e3a8a 0%, #3b82f6 100%);
                        color: white;
                        padding: 20px;
                        text-align: center;
                        font-size: 24px;
                        font-weight: bold;
                        margin-bottom: 20px;
                        border-radius: 8px;
                    }
                    .sub-header {
                        text-align: center;
                        color: #6b7280;
                        margin-bottom: 15px;
                        font-size: 12px;
                    }
                    table {
                        border-collapse: collapse;
                        width: 100%;
                        margin-top: 20px;
                    }
                    th {
                        background-color: #1f2937;
                        color: white;
                        padding: 12px 8px;
                        text-align: center;
                        border: 1px solid #374151;
                        font-size: 12px;
                        font-weight: bold;
                    }
                    td {
                        padding: 10px 8px;
                        text-align: center;
                        border: 1px solid #e5e7eb;
                        font-size: 12px;
                    }
                    .user-cell {
                        text-align: left;
                        font-weight: 500;
                        background-color: #f9fafb;
                    }
                    .role-cell {
                        text-align: center;
                    }
                    .present {
                        color: #059669;
                        font-weight: bold;
                        font-size: 14px;
                    }
                    .absent {
                        color: #dc2626;
                        font-weight: bold;
                        font-size: 14px;
                    }
                    .active {
                        color: #10b981;
                        font-weight: bold;
                        font-size: 12px;
                    }
                    .future {
                        color: #9ca3af;
                        font-size: 14px;
                    }
                    .weekend {
                        background-color: #fef2f2;
                    }
                    .today {
                        background-color: #eff6ff;
                    }
                    .summary-row {
                        background-color: #f3f4f6;
                        font-weight: bold;
                    }
                    .footer {
                        margin-top: 30px;
                        text-align: center;
                        padding: 15px;
                        background-color: #f9fafb;
                        font-size: 10px;
                        color: #6b7280;
                        border-top: 1px solid #e5e7eb;
                    }
                    .legend {
                        margin-top: 20px;
                        padding: 12px;
                        background-color: #f9fafb;
                        border: 1px solid #e5e7eb;
                        font-size: 11px;
                        display: flex;
                        gap: 20px;
                        justify-content: center;
                    }
                    .legend-item {
                        display: inline-flex;
                        align-items: center;
                        gap: 5px;
                    }
                    .green-dot {
                        width: 10px;
                        height: 10px;
                        background-color: #10b981;
                        border-radius: 50%;
                        display: inline-block;
                    }
                </style>
            </head>
            <body>
                <div class="main-header">
                    📋 ${monthDetails.monthName} ${year} - Attendance Report
                </div>
                <div class="sub-header">
                    Generated on: ${new Date().toLocaleString()} | Total Employees: ${filteredUsers.length}
                </div>
        `;

    // Table
    html += `
            <table>
                <thead>
                    <tr>
                        <th style="min-width: 180px;">Employee Name</th>
                        <th style="min-width: 100px;">Role</th>
        `;

    // Add date columns
    visibleDates.forEach((d) => {
      const weekendClass = d.isWeekend ? "weekend" : "";
      html += `
                <th class="${weekendClass}" style="min-width: 60px;">
                    ${d.day}<br>
                    <span style="font-size: 10px;">${d.dayOfWeek}</span>
                </th>
            `;
    });

    // Add summary columns
    html += `
                        <th style="min-width: 70px; background-color: #059669;">P</th>
                        <th style="min-width: 70px; background-color: #dc2626;">A</th>
                        <th style="min-width: 80px;">Hours</th>
                    </tr>
                </thead>
                <tbody>
        `;

    // Data rows
    filteredUsers.forEach((user) => {
      let presentCount = 0;
      let absentCount = 0;
      let totalHours = 0;

      html += `
                <tr>
                    <td class="user-cell">
                        <strong>${user.firstName} ${user.lastName}</strong><br>
                        <span style="font-size: 10px; color: #6b7280;">${user.username}</span>
                    </td>
                    <td class="role-cell">
                        <span style="background: ${user.role === "admin" ? "#3b82f6" : user.role === "subadmin" ? "#10b981" : "#8b5cf6"}; color: white; padding: 4px 8px; border-radius: 12px; font-size: 11px;">
                            ${user.role}
                        </span>
                    </td>
            `;

      // Add attendance for each date
      visibleDates.forEach((d) => {
        const record = user.attendance[d.dateString];
        const workingHours = record
          ? calculateWorkingHours(
            record.loginTime,
            record.logoutTime,
            record.workingHours,
          )
          : 0;
        const isActive = record && !record.logoutTime && record.isActive;

        // For future dates, show "-"
        if (d.isFuture) {
          html += `<td class="future">-</td>`;
        } else if (record && (record.loginTime || workingHours > 0)) {
          if (record.loginTime) presentCount++;
          totalHours += workingHours;

          if (isActive) {
            html += `<td class="active">● Live</td>`;
          } else if (record.isPresent || workingHours > 0) {
            html += `<td class="present">P</td>`;
          } else {
            absentCount++;
            html += `<td class="absent">A</td>`;
          }
        } else {
          absentCount++;
          html += `<td class="absent">A</td>`;
        }
      });

      // Add summary columns
      html += `
                    <td style="text-align: center; background-color: #d1fae5; font-weight: bold; font-size: 16px;">${presentCount}</td>
                    <td style="text-align: center; background-color: #fee2e2; font-weight: bold; font-size: 16px;">${absentCount}</td>
                    <td style="text-align: center; background-color: #eff6ff; font-weight: bold;">${Math.round(totalHours * 60)}m</td>
                </tr>
            `;
    });

    // Add totals row
    const totalPresent = filteredUsers.reduce((sum, user) => {
      return (
        sum +
        Object.values(user.attendance).filter((r) => r && r.loginTime).length
      );
    }, 0);
    const totalAbsent =
      filteredUsers.length * visibleDates.filter((d) => !d.isFuture).length -
      totalPresent;
    const totalHoursAll = filteredUsers.reduce((sum, user) => {
      return (
        sum +
        Object.values(user.attendance).reduce(
          (acc, r) =>
            acc +
            (r
              ? calculateWorkingHours(r.loginTime, r.logoutTime, r.workingHours)
              : 0),
          0,
        )
      );
    }, 0);

    html += `
                    <tr class="summary-row">
                        <td colspan="2" style="text-align: right; font-weight: bold;">TOTAL:</td>
                        ${visibleDates.map(() => "<td></td>").join("")}
                        <td style="text-align: center; background-color: #d1fae5; font-weight: bold; font-size: 18px;">${totalPresent}</td>
                        <td style="text-align: center; background-color: #fee2e2; font-weight: bold; font-size: 18px;">${totalAbsent}</td>
                        <td style="text-align: center; background-color: #eff6ff; font-weight: bold; font-size: 18px;">${Math.round(totalHoursAll * 60)}m</td>
                    </tr>
                </tbody>
            </table>
        `;

    // Legend
    html += `
            <div class="legend">
                <div class="legend-item"><span class="green-dot"></span> <strong>P</strong> = Present</div>
                <div class="legend-item"><span style="color: #dc2626;">●</span> <strong>A</strong> = Absent</div>
                <div class="legend-item"><span style="color: #10b981;">●</span> <strong>Live</strong> = Currently Active</div>
                <div class="legend-item"><span style="color: #9ca3af;">-</span> = Future Date (No data)</div>
                <div class="legend-item"><span style="color: #059669;">📊</span> Minutes = Total Working Minutes</div>
            </div>
            <div class="footer">
                Attendance Report for ${monthDetails.monthName} ${year} | Generated by Attendance Management System
            </div>
            </body>
            </html>
        `;

    return html;
  };

  // Handle Export
  const handleExport = async () => {
    setExporting(true);
    try {
      const htmlContent = generateStyledExcelHTML();
      const blob = new Blob([htmlContent], {
        type: "application/vnd.ms-excel",
      });
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.setAttribute(
        "download",
        `attendance-${monthDetails.monthName}-${year}.xls`,
      );
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Export error:", error);
    } finally {
      setExporting(false);
    }
  };

  // ─── Status / Shift / Location resolver ───────────────────────────────────────
  const resolveDateCellData = (record: AttendanceRecord | undefined) => {
    if (!record || !record.loginTime) return { status: "Absent", dayType: "Full Day", shift: "No shift", location: "No location", hours: "-", checkIn: null, checkOut: null };

    const status = record.isPresent ? "Present" : "Absent";
    const dayType = "Full Day";
    const hours = record.workingHours > 0 ? `${Math.round(record.workingHours * 60)}m` : "-";

    return {
      status,
      dayType,
      shift: record.shiftName || "No shift",
      location: record.checkInPlace || "No location",
      hours,
      checkIn: record.loginTime,
      checkOut: record.logoutTime
    };
  };

  // Render date cell with Table 1 format: Status | Day Type | Shift | Location | Hours
  const renderDateCell = (
    record: AttendanceRecord | undefined,
    isFuture: boolean,
    userId?: string,
    dateString?: string,
  ) => {
    if (isFuture) {
      return (
        <div className="text-gray-400 text-xs relative">
          {canEditAttendanceTime && userId && dateString && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleCreateClick(userId, dateString);
              }}
              className="absolute top-0 right-0 p-1 text-gray-400 hover:text-primary-600 rounded"
              title="Add attendance"
            >
              <Plus className="w-3 h-3" />
            </button>
          )}
          <span>-</span>
        </div>
      );
    }

    if (!record || !record.loginTime) {
      return (
        <div className="text-gray-400 text-xs relative">
          {canEditAttendanceTime && userId && dateString && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleCreateClick(userId, dateString);
              }}
              className="absolute top-0 right-0 p-1 text-gray-400 hover:text-primary-600 rounded"
              title="Add attendance"
            >
              <Plus className="w-3 h-3" />
            </button>
          )}
          <span>Absent</span>
        </div>
      );
    }

    // Table 1 format: Status | Shift | In/Out | Hours
    const resolved = resolveDateCellData(record);

    return (
      <div className="flex flex-col gap-0.5 p-1 text-xs relative">
        {canEditAttendanceTime && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleEditClick(record);
            }}
            className="absolute top-0 right-0 p-1 text-gray-400 hover:text-primary-600 rounded"
            title="Edit attendance time"
          >
            <Edit className="w-3 h-3" />
          </button>
        )}
        <div className="text-left space-y-0.5">
          <div className="flex items-center gap-1">
            <span className={`font-bold ${record.isPresent ? "text-green-600" : "text-red-600"}`}>
              {resolved.status}
            </span>
          </div>
          <div className="text-[10px] text-gray-500">
            {resolved.dayType} | {resolved.shift}
          </div>
          <div className="text-[10px] text-gray-500 flex flex-col">
            <span>In: {formatTime(resolved.checkIn)}</span>
            <span>Out: {resolved.checkOut ? formatTime(resolved.checkOut) : "--"}</span>
          </div>
          <div className="text-[10px] font-semibold text-gray-700">
            {record.workingHours > 0 ? `${record.workingHours}h` : "-"}
          </div>
        </div>
        {!record.logoutTime && record.isActive && (
          <div className="mt-0.5">
            <div className="flex items-center gap-1">
              <Wifi className="w-3 h-3 text-green-500 animate-pulse" />
              <span className="text-green-600 text-xs font-medium">Active</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  // Get role badge color
  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "superadmin":
        return "bg-purple-100 text-purple-700";
      case "admin":
        return "bg-blue-100 text-blue-700";
      case "subadmin":
        return "bg-green-100 text-green-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  // Check if user can edit attendance time
  const canEditAttendanceTime = user?.role === 'admin' && user?.granularPermissions?.canEditAttendanceTime === true;

  const handleEditClick = (record: AttendanceRecord) => {
    if (!canEditAttendanceTime) return;

    // Get the date for datetime-local format
    const recordDate = record.date instanceof Date
      ? record.date.toISOString().split('T')[0]
      : (typeof record.date === 'string' ? record.date : '');

    // Format time for datetime-local input (convert "9:00:00 AM" to "T09:00")
    const formatToDateTimeLocal = (timeStr: string | null | undefined) => {
      if (!timeStr) return `${recordDate}T09:00`;
      const matches = String(timeStr).match(/(\d{1,2}):(\d{2})/);
      if (matches) {
        const hours = matches[1].padStart(2, '0');
        return `${recordDate}T${hours}:${matches[2]}`;
      }
      return "";
    };

    setEditingRecord(record);
    setEditCheckIn(formatToDateTimeLocal(record.loginTime));
    setEditCheckOut(formatToDateTimeLocal(record.logoutTime));
    setEditStatus(record.isPresent ? "present" : "absent");
    setEditShiftName(record.shiftName || "");
    setShowEditModal(true);



  };

  const handleCloseEditModal = () => {
    setShowEditModal(false);
    setEditingRecord(null);
    setEditCheckIn("");
    setEditCheckOut("");
    setEditStatus("present");
    setEditShiftName("");
  };

  const handleCreateClick = (userId: string, dateString: string) => {
    if (!canEditAttendanceTime) return;
    setCreateAttendanceUserId(userId);
    setCreateAttendanceDate(dateString);
    setCreateAttendanceStatus("present");
    setCreateCheckIn(`${dateString}T09:00`);
    setCreateCheckOut(`${dateString}T18:00`);
    setShowCreateModal(true);
  };

  const handleCloseCreateModal = () => {
    setShowCreateModal(false);
    setCreateAttendanceDate(null);
    setCreateAttendanceUserId(null);
    setCreateAttendanceStatus("present");
    setCreateCheckIn("");
    setCreateCheckOut("");
    setCreateShiftName("");
  };

  const handleCreateAttendance = async () => {
    if (!createAttendanceUserId || !createAttendanceDate) return;

    setCreatingAttendance(true);
    try {
      // Convert datetime-local values to ISO strings for API
      const checkInISO = createCheckIn ? new Date(createCheckIn).toISOString() : null;
      const checkOutISO = createCheckOut ? new Date(createCheckOut).toISOString() : null;

      const payload: any = {
        userId: createAttendanceUserId,
        date: createAttendanceDate,
        status: createAttendanceStatus,
      };

      // Add shift times
      if (checkInISO && checkOutISO) {
        payload.checkIn = checkInISO;
        payload.checkOut = checkOutISO;
      }

      // Add shift name
      if (createShiftName) {
        payload.shift = createShiftName;
      }

      await apiClient.createAttendance(payload);
      alert("Attendance created successfully");
      handleCloseCreateModal();
      // Refresh attendance data
      setCurrentDate(new Date(currentDate));
    } catch (error: any) {
      console.error("Error creating attendance:", error);
      alert(error.response?.message || error.message || "Failed to create attendance");
    } finally {
      setCreatingAttendance(false);
    }
  };

  const handleSaveAttendanceEdit = async () => {
    if (!editingRecord || !editingRecord._id) return;

    // Parse datetime-local values to ISO strings
    const checkInISO = editCheckIn ? new Date(editCheckIn).toISOString() : null;
    const checkOutISO = editCheckOut ? new Date(editCheckOut).toISOString() : null;

    setSavingEdit(true);
    try {
      await apiClient.updateAttendanceTime(editingRecord._id, {
        checkIn: checkInISO,
        checkOut: checkOutISO,
        status: editStatus,
        shift: editShiftName || undefined,
      });
      // Refresh attendance data
      setCurrentDate(new Date(currentDate));
      handleCloseEditModal();
    } catch (error: any) {
      console.error("Error saving attendance:", error?.message || error);
      alert(error?.message || error?.response?.data?.message || "Failed to save attendance");
    } finally {
      setSavingEdit(false);
    }
  };

  // For subadmins, show their own attendance only
  if (user?.role === "subadmin") {
    return <SubAdminAttendanceNew />;
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-4 md:p-6">
      <div className="max-w-[95vw] mx-auto">
        {/* Page Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Attendance Management
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            Track user login/logout times and working hours by date
          </p>
        </div>

        {/* Month Selector and Controls */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 mb-4">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center flex-wrap gap-2">
              <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
                <button
                  onClick={handlePrevMonth}
                  className="p-2 rounded-md hover:bg-white dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300 transition-colors"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>

                <div className="flex items-center gap-2 px-4 min-w-[160px] justify-center">
                  <Calendar className="w-4 h-4 text-gray-400" />
                  <span className="text-base font-semibold text-gray-900 dark:text-white whitespace-nowrap">
                    {monthDetails.monthName} {year}
                  </span>
                </div>

                <button
                  onClick={handleNextMonth}
                  className="p-2 rounded-md hover:bg-white dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300 transition-colors"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
              </div>

              <button
                onClick={() => setCurrentDate(new Date())}
                className="px-4 py-2 text-sm font-medium text-primary-600 hover:text-primary-700 border border-primary-200 rounded-lg hover:bg-primary-50 transition-colors bg-white dark:bg-gray-800 dark:border-gray-600 dark:text-primary-400 dark:hover:bg-gray-700"
              >
                Current Month
              </button>
            </div>

            <button
              onClick={handleExport}
              disabled={exporting}
              className="flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50"
            >
              {exporting ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Download className="w-4 h-4" />
              )}
              Export Excel
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 mb-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder="Search by name or username..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary-500"
              />
              <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
            </div>

            {/* Hide Superadmin Toggle Button 
                        <div className="flex items-center gap-2">
                            <button
                                onClick={() => setHideSuperadmin(!hideSuperadmin)}
                                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${hideSuperadmin
                                    ? 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400 border border-purple-200 dark:border-purple-700'
                                    : 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400 border border-gray-200 dark:border-gray-600'
                                    }`}
                            >
                                {hideSuperadmin ? (
                                    <>
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                        </svg>
                                        Hide Superadmin
                                    </>
                                ) : (
                                    <>
                                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                        Show Superadmin
                                    </>
                                )}
                            </button>
                        </div>*/}
          </div>
        </div>
        {/* Attendance Table with Date Columns */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 text-primary-600 animate-spin" />
            </div>
          ) : (
            <>
              {/* Desktop Table View */}
              <div className="hidden lg:block overflow-x-auto">
                <table className="w-full min-w-[1400px]">
                  <thead className="bg-gray-50 dark:bg-gray-700/50 border-b border-gray-200 dark:border-gray-700">
                    <tr>
                      <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider sticky left-0 bg-gray-50 dark:bg-gray-700/50 z-10 min-w-[150px]">
                        User Name
                      </th>
                      <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider sticky left-[150px] bg-gray-50 dark:bg-gray-700/50 z-10 min-w-[100px]">
                        Role
                      </th>
                      <th className="px-3 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider sticky left-[250px] bg-gray-50 dark:bg-gray-700/50 z-10 min-w-[120px]">
                        Dealer
                      </th>
                      {visibleDates.map((d) => (
                        <th
                          key={d.dateString}
                          className={`px-2 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider min-w-[140px] ${d.isToday ? "bg-primary-50 dark:bg-primary-900/20" : ""}`}
                        >
                          <div className="flex flex-col">
                            <span className={d.isWeekend ? "text-red-500" : ""}>
                              {d.dayOfWeek}
                            </span>
                            <span
                              className={`font-bold ${d.isToday ? "text-primary-600" : ""}`}
                            >
                              {d.day}/{month}
                            </span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {filteredUsers.length === 0 ? (
                      <tr>
                        <td
                          colSpan={visibleDates.length + 3}
                          className="px-6 py-12 text-center text-gray-500 dark:text-gray-400"
                        >
                          No attendance records found for this month
                        </td>
                      </tr>
                    ) : (
                      paginatedUsers.map((user) => (
                        <tr
                          key={user.userId}
                          className="hover:bg-gray-50 dark:hover:bg-gray-700/30"
                        >
                          {/* User Name Column */}
                          <td className="px-3 py-3 sticky left-0 bg-white dark:bg-gray-800 z-10">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                                <span className="text-primary-600 dark:text-primary-400 text-sm font-medium">
                                  {user.firstName?.[0]}
                                  {user.lastName?.[0]}
                                </span>
                              </div>
                              <div className="ml-3">
                                <div className="text-sm font-medium text-gray-900 dark:text-white">
                                  {user.firstName} {user.lastName}
                                </div>
                                <div className="text-xs text-gray-500 dark:text-gray-400">
                                  {user.username}
                                </div>
                              </div>
                            </div>
                          </td>

                          {/* Role Column */}
                          <td className="px-3 py-3 sticky left-[150px] bg-white dark:bg-gray-800 z-10">
                            <span
                              className={`px-2 py-1 text-xs font-medium rounded-full capitalize ${getRoleBadgeColor(user.role)}`}
                            >
                              {user.role}
                            </span>
                          </td>

                          {/* Dealer Column */}
                          <td className="px-3 py-3 sticky left-[250px] bg-white dark:bg-gray-800 z-10">
                            <div className="text-sm text-gray-900 dark:text-white">
                              {user.tenantId?.companyName ||
                                user.tenantId?.name ||
                                "-"}
                            </div>
                          </td>

                          {/* Date Columns */}
                          {visibleDates.map((d) => {
                            const record = user.attendance[d.dateString];
                            return (
                              <td
                                key={d.dateString}
                                className={`px-2 py-2 text-center ${d.isToday ? "bg-primary-50/50 dark:bg-primary-900/10" : ""}`}
                              >
                                {renderDateCell(record, d.isFuture, user.userId, d.dateString)}
                              </td>
                            );
                          })}
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View */}
              <div className="lg:hidden divide-y divide-gray-200 dark:divide-gray-700">
                {filteredUsers.length === 0 ? (
                  <div className="p-8 text-center text-gray-500">
                    No records found
                  </div>
                ) : (
                  paginatedUsers.map((user) => {
                    // Calculate summary
                    const monthAttendance = Object.values(user.attendance);
                    const presentCount = monthAttendance.filter(r => r.isPresent).length;
                    const todayStr = new Date().toISOString().split('T')[0];
                    const todayRecord = user.attendance[todayStr];

                    return (
                      <div
                        key={user.userId}
                        className="p-4 space-y-4 hover:bg-gray-50 dark:hover:bg-gray-800/40 transition-colors cursor-pointer"
                        onClick={() => {
                          setSelectedUserAttendance(user);
                          setShowAttendanceModal(true);
                        }}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center">
                            <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                              <span className="text-primary-600 dark:text-primary-400 font-bold">
                                {user.firstName?.[0]}{user.lastName?.[0]}
                              </span>
                            </div>
                            <div className="ml-3">
                              <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                                {user.firstName} {user.lastName}
                              </h3>
                              <p className="text-xs text-gray-500">@{user.username}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-1 text-[10px] font-bold rounded-full uppercase ${getRoleBadgeColor(user.role)}`}>
                              {user.role}
                            </span>
                            <ChevronRight size={16} className="text-gray-400" />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="bg-blue-50/50 dark:bg-blue-900/10 p-3 rounded-xl border border-blue-100 dark:border-blue-800/50">
                            <p className="text-[10px] text-blue-600 dark:text-blue-400 font-bold uppercase mb-1">Today's Status</p>
                            <div className="mt-1">
                              {renderDateCell(todayRecord, false)}
                            </div>
                          </div>
                          <div className="bg-green-50/50 dark:bg-green-900/10 p-3 rounded-xl border border-green-100 dark:border-green-800/50">
                            <p className="text-[10px] text-green-600 dark:text-green-400 font-bold uppercase mb-1">Month Summary</p>
                            <div className="flex flex-col gap-1 mt-1">
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-gray-500">Present</span>
                                <span className="text-xs font-bold text-green-600">{presentCount}</span>
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-xs text-gray-500">Working</span>
                                <span className="text-xs font-bold text-blue-600">
                                  {Math.round(monthAttendance.reduce((acc, r) => acc + (r.workingHours || 0), 0) * 60)}m
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {user.tenantId && (
                          <div className="flex items-center justify-between text-xs">
                            <div className="flex items-center gap-2 text-gray-500">
                              <Building size={14} />
                              <span>{user.tenantId.companyName || user.tenantId.name}</span>
                            </div>
                            <span className="text-primary-600 font-medium text-[10px] uppercase">View Full Log</span>
                          </div>
                        )}
                      </div>
                    );
                  })
                )}
              </div>
            </>
          )}
        </div>

        {/* Pagination */}
        {filteredUsers.length > ITEMS_PER_PAGE && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800">
            <div className="text-sm text-gray-500">
              Showing {(currentPage - 1) * ITEMS_PER_PAGE + 1} -{" "}
              {Math.min(currentPage * ITEMS_PER_PAGE, filteredUsers.length)} of{" "}
              {filteredUsers.length}
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setCurrentPage(1)}
                disabled={currentPage === 1}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronFirst size={18} />
              </button>
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLeft size={18} />
              </button>
              <span className="text-sm font-medium px-3">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={() => setCurrentPage((p) => p + 1)}
                disabled={currentPage >= totalPages}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronRight size={18} />
              </button>
              <button
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage >= totalPages}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 disabled:opacity-30 disabled:cursor-not-allowed"
              >
                <ChevronLast size={18} />
              </button>
            </div>
          </div>
        )}

        {/* Legend */}
        <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
          <div className="flex items-center gap-2">
            <span className="font-medium">Legend:</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-xs text-blue-600 font-medium">Check In</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-xs text-orange-600">Check Out</span>
          </div>
          <div className="flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span className="text-xs">Working Minutes</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-green-600 font-bold text-xs">P</span>
            <span className="text-xs">Present</span>
          </div>
          <div className="flex items-center gap-1">
            <Wifi className="w-3 h-3 text-green-500" />
            <span className="text-xs">Active Now</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-gray-400 text-xs">-</span>
            <span className="text-xs">Future Date / No Data</span>
          </div>
        </div>

        {/* User Attendance Details Modal */}
        {showAttendanceModal && selectedUserAttendance && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between bg-gray-50 dark:bg-gray-800/50">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center">
                    <span className="text-primary-600 dark:text-primary-400 font-bold uppercase">
                      {selectedUserAttendance.firstName?.[0]}{selectedUserAttendance.lastName?.[0]}
                    </span>
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                      {selectedUserAttendance.firstName} {selectedUserAttendance.lastName}
                    </h3>
                    <p className="text-xs text-gray-500">Monthly Attendance Log</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowAttendanceModal(false)}
                  className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors"
                >
                  <X size={20} className="text-gray-500 dark:text-gray-400" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto p-4 space-y-3 no-scrollbar">
                {visibleDates.slice().reverse().map((d) => {
                  const record = selectedUserAttendance.attendance[d.dateString];
                  if (d.isFuture) return null;

                  return (
                    <div
                      key={d.dateString}
                      className={`p-3 rounded-xl border ${d.isToday ? 'bg-primary-50/50 border-primary-100 dark:bg-primary-900/10 dark:border-primary-900/30' : 'bg-white dark:bg-gray-900 border-gray-100 dark:border-gray-800'}`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className={`text-xs font-bold ${d.isWeekend ? 'text-red-500' : 'text-gray-900 dark:text-white'}`}>
                            {d.day} {monthDetails.monthName}
                          </span>
                          <span className="text-[10px] text-gray-400 uppercase">{d.dayOfWeek}</span>
                        </div>
                        {d.isToday && <span className="px-2 py-0.5 bg-primary-100 dark:bg-primary-900/40 text-primary-700 dark:text-primary-300 text-[10px] font-bold rounded-full uppercase">Today</span>}
                      </div>

                      {record && record.loginTime ? (
                        <div className="grid grid-cols-3 gap-2">
                          <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 uppercase">Check In</span>
                            <span className="text-xs font-bold text-blue-600">{formatTime(record.loginTime)}</span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 uppercase">Check Out</span>
                            <span className="text-xs font-bold text-orange-600">{formatTime(record.logoutTime)}</span>
                          </div>
                          <div className="flex flex-col">
                            <span className="text-[10px] text-gray-400 uppercase">Duration</span>
                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">
                              {Math.round((record.workingMinutes || record.workingHours * 60))}m
                            </span>
                          </div>
                        </div>
                      ) : (
                        <div className="text-center py-1 text-xs text-gray-400 italic">No attendance record</div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div className="p-4 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                <button
                  onClick={() => setShowAttendanceModal(false)}
                  className="w-full py-3 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl text-sm font-bold text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-800 transition-colors shadow-sm"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Edit Attendance Modal */}
        {showEditModal && editingRecord && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col">
              <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between bg-gray-50 dark:bg-gray-800/50">
                <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                  Edit Attendance
                </h3>
                <button
                  onClick={handleCloseEditModal}
                  className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors"
                >
                  <X size={20} className="text-gray-500 dark:text-gray-400" />
                </button>
              </div>

              <div className="p-4 space-y-4">
                {/* Status Selection */}
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-2">
                    Status
                  </label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setEditStatus("present")}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${editStatus === "present"
                        ? "bg-green-600 text-white"
                        : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200"
                        }`}
                    >
                      Present
                    </button>
                    <button
                      onClick={() => setEditStatus("half-day")}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${editStatus === "half-day"
                        ? "bg-orange-600 text-white"
                        : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200"
                        }`}
                    >
                      Half Day
                    </button>
                    <button
                      onClick={() => setEditStatus("absent")}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${editStatus === "absent"
                        ? "bg-red-600 text-white"
                        : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200"
                        }`}
                    >
                      Absent
                    </button>
                  </div>
                </div>

                {/* Check In Time */}
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">
                    Check In Time
                  </label>
                  <input
                    type="datetime-local"
                    value={editCheckIn}
                    onChange={(e) => setEditCheckIn(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
                  />
                </div>

                {/* Check Out Time */}
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">
                    Check Out Time
                  </label>
                  <input
                    type="datetime-local"
                    value={editCheckOut}
                    onChange={(e) => setEditCheckOut(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
                  />
                </div>

                {/* Shift Name */}
                <div>
                  <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">
                    Shift Required*
                  </label>
                  <input
                    type="text"
                    value={editShiftName}
                    onChange={(e) => setEditShiftName(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
                    placeholder="e.g., General Shift"
                  />
                </div>
              </div>

              <div className="p-4 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                <div className="flex gap-2">
                  <button
                    onClick={handleCloseEditModal}
                    disabled={savingEdit}
                    className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold hover:bg-gray-50 dark:hover:bg-gray-800 transition-all disabled:opacity-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={handleSaveAttendanceEdit}
                    disabled={savingEdit}
                    className="flex-1 px-4 py-2 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-bold transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {savingEdit ? (
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4" />
                        Save Changes
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}


        {/* Create Attendance Modal */}
        {
          showCreateModal && createAttendanceDate && (
            <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col">
                <div className="p-4 border-b border-gray-100 dark:border-gray-700 flex items-center justify-between bg-gray-50 dark:bg-gray-800/50">
                  <h3 className="text-sm font-bold text-gray-900 dark:text-white">
                    Create Attendance - {createAttendanceDate}
                  </h3>
                  <button
                    onClick={handleCloseCreateModal}
                    className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-full transition-colors"
                  >
                    <X size={20} className="text-gray-500 dark:text-gray-400" />
                  </button>
                </div>

                <div className="p-4 space-y-4">
                  {/* Status Selection */}
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-2">
                      Status
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => setCreateAttendanceStatus("present")}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${createAttendanceStatus === "present"
                          ? "bg-green-600 text-white"
                          : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200"
                          }`}
                      >
                        Present
                      </button>
                      <button
                        onClick={() => setCreateAttendanceStatus("half-day")}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${createAttendanceStatus === "half-day"
                          ? "bg-orange-600 text-white"
                          : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200"
                          }`}
                      >
                        Half Day
                      </button>
                      <button
                        onClick={() => setCreateAttendanceStatus("absent")}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${createAttendanceStatus === "absent"
                          ? "bg-red-600 text-white"
                          : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200"
                          }`}
                      >
                        Absent
                      </button>
                    </div>
                  </div>

                  {/* Check In Time */}
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">
                      Check In Time
                    </label>
                    <input
                      type="datetime-local"
                      value={createCheckIn}
                      onChange={(e) => setCreateCheckIn(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
                    />
                  </div>

                  {/* Check Out Time */}
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">
                      Check Out Time
                    </label>
                    <input
                      type="datetime-local"
                      value={createCheckOut}
                      onChange={(e) => setCreateCheckOut(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
                    />
                  </div>

                  {/* Shift Name */}
                  <div>
                    <label className="block text-xs font-semibold text-gray-600 dark:text-gray-400 mb-1">
                      Shift (optional)
                    </label>
                    <input
                      type="text"
                      value={createShiftName}
                      onChange={(e) => setCreateShiftName(e.target.value)}
                      className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
                      placeholder="e.g., General Shift"
                    />
                  </div>
                </div>

                <div className="p-4 border-t border-gray-100 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/50">
                  <div className="flex gap-2">
                    <button
                      onClick={handleCloseCreateModal}
                      disabled={creatingAttendance}
                      className="flex-1 px-4 py-2 rounded-xl border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 font-semibold hover:bg-gray-50 dark:hover:bg-gray-800 transition-all disabled:opacity-50"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleCreateAttendance}
                      disabled={creatingAttendance}
                      className="flex-1 px-4 py-2 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-bold transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                    >
                      {creatingAttendance ? (
                        <>
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                          Creating...
                        </>
                      ) : (
                        <>
                          <CheckCircle className="w-4 h-4" />
                          Create
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )
        }
      </div >
    </div >
  );
}

// Search Icon Component
function SearchIcon({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
      />
    </svg>
  );
}

// SubAdmin View - Personal attendance history (keeping original UI)
function SubAdminAttendanceNew() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [attendanceData, setAttendanceData] = useState<AttendanceRecord[]>([]);
  const [currentDate, setCurrentDate] = useState(new Date());

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth() + 1;
  const monthDetails = getMonthDetails(year, month);
  const datesInMonth = useMemo(
    () => getDatesInMonth(year, month),
    [year, month],
  );

  const visibleDates = datesInMonth;
  const startDate = useMemo(
    () => new Date(year, month - 1, 1).toISOString().split("T")[0],
    [year, month],
  );
  const endDate = useMemo(
    () => new Date(year, month, 0).toISOString().split("T")[0],
    [year, month],
  );

  useEffect(() => {
    const fetchMyAttendance = async () => {
      setLoading(true);
      try {
        const response = await apiClient.getMyAttendance({
          startDate,
          endDate,
          limit: 100,
        });

        if (response && response.logs) {
          setAttendanceData(response.logs);
        }
      } catch (error) {
        console.error("Error fetching attendance:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchMyAttendance();
  }, [startDate, endDate]);

  // Group by date
  const attendanceByDate = useMemo(() => {
    const map: { [date: string]: AttendanceRecord } = {};
    attendanceData.forEach((record) => {
      if (record.loginTime) {
        const dateStr = new Date(record.loginTime).toISOString().split("T")[0];
        if (
          !map[dateStr] ||
          calculateWorkingHours(
            record.loginTime,
            record.logoutTime,
            record.workingHours,
          ) >
          calculateWorkingHours(
            map[dateStr].loginTime,
            map[dateStr].logoutTime,
            map[dateStr].workingHours,
          )
        ) {
          map[dateStr] = record;
        }
      }
    });
    return map;
  }, [attendanceData]);

  const handlePrevMonth = () => setCurrentDate(new Date(year, month - 2, 1));
  const handleNextMonth = () => setCurrentDate(new Date(year, month, 1));

  const renderDateCell = (
    record: AttendanceRecord | undefined,
    isFuture: boolean,
  ) => {
    if (isFuture) {
      return <span className="text-gray-400 text-xs">-</span>;
    }

    if (!record || !record.loginTime) {
      return <span className="text-gray-400 text-xs">-</span>;
    }

    const workingHours = calculateWorkingHours(
      record.loginTime,
      record.logoutTime,
      record.workingHours,
    );
    const isActive = !record.logoutTime && record.isActive;

    return (
      <div className="space-y-1 text-xs">
        <div className="text-blue-600">{formatTime(record.loginTime)}</div>
        <div className="text-orange-600">{formatTime(record.logoutTime)}</div>
        <div className="text-gray-500">
          {record.workingHours > 0 ? `${Math.round(record.workingHours * 60)}m` : "-"}
        </div>
        {isActive ? (
          <span className="text-green-500">● Active</span>
        ) : (
          record.isPresent && (
            <span className="text-green-600 font-bold">P</span>
          )
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            My Attendance
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
            View your login/logout times and working hours
          </p>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4 mb-6">
          <div className="flex flex-wrap items-center justify-center gap-4">
            <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 rounded-lg p-1">
              <button
                onClick={handlePrevMonth}
                className="p-2 rounded-md hover:bg-white dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <div className="flex items-center gap-2 px-4 min-w-[160px] justify-center">
                <Calendar className="w-4 h-4 text-gray-400" />
                <span className="text-base font-semibold text-gray-900 dark:text-white whitespace-nowrap">
                  {monthDetails.monthName} {year}
                </span>
              </div>
              <button
                onClick={handleNextMonth}
                className="p-2 rounded-md hover:bg-white dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300 transition-colors"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
            <button
              onClick={() => setCurrentDate(new Date())}
              className="px-4 py-2 text-sm font-medium text-primary-600 hover:text-primary-700 border border-primary-200 rounded-lg hover:bg-primary-50 transition-colors bg-white dark:bg-gray-800 dark:border-gray-600 dark:text-primary-400 dark:hover:bg-gray-700"
            >
              Current Month
            </button>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary-600" />
            </div>
          ) : (
            <>
              {/* Desktop View */}
              <div className="hidden sm:block overflow-x-auto">
                <table className="w-full min-w-[800px]">
                  <thead className="bg-gray-50 dark:bg-gray-700/50">
                    <tr>
                      <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Day
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Check In
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Check Out
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Duration
                      </th>
                      <th className="px-6 py-4 text-left text-xs font-bold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                        Status
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100 dark:divide-gray-700">
                    {visibleDates.slice().reverse().map((d) => {
                      const record = attendanceByDate[d.dateString];
                      const hours = record
                        ? calculateWorkingHours(
                          record.loginTime,
                          record.logoutTime,
                          record.workingHours,
                        )
                        : 0;
                      const isActive =
                        record && !record.logoutTime && record.isActive;

                      return (
                        <tr
                          key={d.dateString}
                          className={`hover:bg-gray-50 dark:hover:bg-gray-700/30 transition-colors ${d.isToday ? "bg-primary-50/30 dark:bg-primary-900/10" : ""}`}
                        >
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">
                            {d.day} {monthDetails.monthName}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                            {d.dayOfWeek}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-600 dark:text-blue-400 font-medium">
                            {record ? formatTime(record.loginTime) : "-"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-orange-600 dark:text-orange-400 font-medium">
                            {record ? formatTime(record.logoutTime) : "-"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-300">
                            {hours > 0 ? `${Math.round(hours * 60)}m` : "-"}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {isActive ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400">
                                <span className="w-1.5 h-1.5 rounded-full bg-green-500 mr-1.5 animate-pulse"></span>
                                Active
                              </span>
                            ) : record && record.isPresent ? (
                              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-bold bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400">
                                Present
                              </span>
                            ) : (
                              <span className="text-gray-400 text-sm">-</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Mobile Card View */}
              <div className="sm:hidden divide-y divide-gray-100 dark:divide-gray-700">
                {visibleDates.slice().reverse().map((d) => {
                  const record = attendanceByDate[d.dateString];
                  if (d.isFuture) return null;

                  const hours = record
                    ? calculateWorkingHours(
                      record.loginTime,
                      record.logoutTime,
                      record.workingHours,
                    )
                    : 0;
                  const isActive = record && !record.logoutTime && record.isActive;

                  return (
                    <div
                      key={d.dateString}
                      className={`p-4 space-y-3 ${d.isToday ? 'bg-primary-50/30 dark:bg-primary-900/10' : ''}`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`text-sm font-bold ${d.isWeekend ? 'text-red-500' : 'text-gray-900 dark:text-white'}`}>
                            {d.day} {monthDetails.monthName}
                          </span>
                          <span className="text-[10px] text-gray-400 uppercase font-bold">{d.dayOfWeek}</span>
                        </div>
                        {isActive ? (
                          <span className="px-2 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-[10px] font-bold rounded-full uppercase flex items-center gap-1">
                            <span className="w-1 h-1 rounded-full bg-green-500 animate-pulse"></span>
                            Active
                          </span>
                        ) : d.isToday ? (
                          <span className="px-2 py-0.5 bg-primary-100 dark:bg-primary-900/30 text-primary-700 dark:text-primary-300 text-[10px] font-bold rounded-full uppercase">Today</span>
                        ) : null}
                      </div>

                      {record && record.loginTime ? (
                        <div className="grid grid-cols-3 gap-2">
                          <div className="bg-blue-50/50 dark:bg-blue-900/10 p-2 rounded-xl border border-blue-100/50 dark:border-blue-900/30">
                            <span className="text-[9px] text-blue-600 dark:text-blue-400 uppercase font-bold block mb-1">In</span>
                            <span className="text-xs font-bold text-blue-700 dark:text-blue-300">{formatTime(record.loginTime)}</span>
                          </div>
                          <div className="bg-orange-50/50 dark:bg-orange-900/10 p-2 rounded-xl border border-orange-100/50 dark:border-orange-900/30">
                            <span className="text-[9px] text-orange-600 dark:text-orange-400 uppercase font-bold block mb-1">Out</span>
                            <span className="text-xs font-bold text-orange-700 dark:text-orange-300">{formatTime(record.logoutTime)}</span>
                          </div>
                          <div className="bg-gray-50 dark:bg-gray-800 p-2 rounded-xl border border-gray-100 dark:border-gray-700">
                            <span className="text-[9px] text-gray-500 uppercase font-bold block mb-1">Work</span>
                            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">{Math.round(hours * 60)}m</span>
                          </div>
                        </div>
                      ) : (
                        <div className="text-xs text-gray-400 italic py-1">No record for this day</div>
                      )}
                    </div>
                  );
                })}
              </div>
            </>
          )}
        </div>

        <div className="grid grid-cols-3 gap-4 mt-6">
          <div className="bg-white p-4 rounded-lg border text-center">
            <p className="text-sm text-gray-500">Total Days</p>
            <p className="text-2xl font-bold">{visibleDates.length}</p>
          </div>
          <div className="bg-white p-4 rounded-lg border text-center">
            <p className="text-sm text-gray-500">Present</p>
            <p className="text-2xl font-bold text-green-600">
              {
                Object.values(attendanceByDate).filter((r) => r && r.loginTime)
                  .length
              }
            </p>
          </div>
          <div className="bg-white p-4 rounded-lg border text-center">
            <p className="text-sm text-gray-500">Total Hours</p>
            <p className="text-2xl font-bold text-blue-600">
              {Math.round(
                Object.values(attendanceByDate).reduce(
                  (sum, r) =>
                    sum +
                    (r
                      ? calculateWorkingHours(
                        r.loginTime,
                        r.logoutTime,
                        r.workingHours,
                      )
                      : 0),
                  0,
                ) * 60,
              )}
              m
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
